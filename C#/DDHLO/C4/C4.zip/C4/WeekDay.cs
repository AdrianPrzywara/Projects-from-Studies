﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C4
{
    enum WeekDay
    {
        Monday,
        Tuesday,
        Wednesday,
        Thursday,
        Friday,
        Saturday,
        Sunday
    }
}
