﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework_C2
{
    abstract class Human
    {
        public abstract int Cost(int months);
    }
}
