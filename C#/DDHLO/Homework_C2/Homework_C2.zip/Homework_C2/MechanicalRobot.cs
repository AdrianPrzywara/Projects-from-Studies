﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Homework_C2
{
    class MechanicalRobot : Robot
    {
        public MechanicalRobot() : base("MechanicalRobot") { }
    }
}
