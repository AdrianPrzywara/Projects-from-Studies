﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C3
{
    class Crewman : Human
    {
    }
}
