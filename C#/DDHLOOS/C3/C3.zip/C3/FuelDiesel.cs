﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C3
{
    class FuelDiesel : Fuel
    {
        public FuelDiesel(): base("Diesel", 5.7) { }
    }
}
