﻿using System;
using System.Collections.Generic;
using System.Text;

namespace C3
{
    class FuelNuclear : Fuel
    {
        public FuelNuclear() : base("Nuclear", 6.8) { }
    }
}
