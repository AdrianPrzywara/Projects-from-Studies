﻿using System;

namespace Spaceship
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Battle Started\n");
            RunBattle.Run();
            Console.WriteLine("\nBattle Ended");
        }
    }
}
